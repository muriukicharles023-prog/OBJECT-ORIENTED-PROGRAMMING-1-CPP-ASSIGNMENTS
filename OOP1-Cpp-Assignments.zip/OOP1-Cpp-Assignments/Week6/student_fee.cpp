//Student Fee Management System (Classes and Objects)

#include <iostream>
#include <string>
using namespace std;

class Student{
    private:
        string student_name;
        string admission_number;
        float fee_balance;

    public:
        //input student details
        void inputStudent(){
            cout<<"Enter student name: "<<endl;
            cin>>student_name;
            cout<<"Enter admission number: "<<endl;
            cin>>admission_number;
            cout<<"Enter fee balance: "<<endl;
            cin>>fee_balance;
        }

        //reduce the fee balance when a payment is made
        void makePayment(float amount){
            if (amount <= 0){
                cout<<"Invalid payment amount"<<endl;
            }
            else if (amount > fee_balance){
                cout<<"Payment is more than the fee balance"<<endl;
            }
            else{
                fee_balance = fee_balance - amount;
                cout<<"Payment of Ksh. "<<amount<<" received"<<endl;
            }
        }

        //display student details and remaining balance
        void displayStatus(){
            cout<<"\n";
            cout<<"STUDENT FEE STATUS "<<endl;
            cout<<"==================================="<<endl;
            cout<<"Student name: "<<student_name<<endl;
            cout<<"Admission number: "<<admission_number<<endl;
            cout<<"Fee balance = Ksh. "<<fee_balance<<endl;
            cout<<"==================================="<<endl;
        }
};

int main(){
    //create an object of the class
    Student student1;
    float payment;

    student1.inputStudent();

    cout<<"Enter payment amount: "<<endl;
    cin>>payment;
    student1.makePayment(payment);

    student1.displayStatus();

    return 0;
}
