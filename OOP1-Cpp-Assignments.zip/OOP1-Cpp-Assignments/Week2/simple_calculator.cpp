//Simple Calculator (switch statement)

#include <iostream>
using namespace std;

int main(){
    float number1, number2, result;
    char op;

    cout<<"Enter first number: "<<endl;
    cin>>number1;
    cout<<"Enter operator (+, -, *, /): "<<endl;
    cin>>op;
    cout<<"Enter second number: "<<endl;
    cin>>number2;

    cout<<"\n";
    cout<<"SIMPLE CALCULATOR "<<endl;
    cout<<"==================================="<<endl;

    //switch statement to select the operation
    switch (op){
        case '+':
            result = number1 + number2;
            cout<<number1<<" + "<<number2<<" = "<<result<<endl;
            break;
        case '-':
            result = number1 - number2;
            cout<<number1<<" - "<<number2<<" = "<<result<<endl;
            break;
        case '*':
            result = number1 * number2;
            cout<<number1<<" * "<<number2<<" = "<<result<<endl;
            break;
        case '/':
            //handle division by zero
            if (number2 == 0){
                cout<<"Error: Division by zero is not allowed"<<endl;
            }
            else{
                result = number1 / number2;
                cout<<number1<<" / "<<number2<<" = "<<result<<endl;
            }
            break;
        default:
            cout<<"Error: Invalid operator"<<endl;
    }
    cout<<"==================================="<<endl;

    return 0;
}
