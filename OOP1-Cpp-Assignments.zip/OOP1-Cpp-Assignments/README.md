# OOP1-Cpp-Assignments

Weekly C++ assignments for **SPC 2204 Object-Oriented Programming I**.
New weeks are added as the unit is covered.

## Assignments submitted so far

| Week | Topic | Program | File |
|------|-------|---------|------|
| 1 | Basics, input/output | Mobile Phone Sales Receipt System | [sales_receipt.cpp](Week1/sales_receipt.cpp) |
| 1 | Basics, input/output | Driving Test Result Evaluation System | [driving_test.cpp](Week1/driving_test.cpp) |
| 2 | Decision making | Grading System (if-else ladder) | [grading_system.cpp](Week2/grading_system.cpp) |
| 2 | Decision making | Admission Decision (nested if) | [admission_decision.cpp](Week2/admission_decision.cpp) |
| 2 | Decision making | Simple Calculator (switch) | [simple_calculator.cpp](Week2/simple_calculator.cpp) |
| 3 | Functions | Payroll System | [payroll_system.cpp](Week3/payroll_system.cpp) |
| 3 | Functions | Water Billing System | [water_billing.cpp](Week3/water_billing.cpp) |
| 6 | Classes and objects | Library Book Management System | [library_book.cpp](Week6/library_book.cpp) |
| 6 | Classes and objects | Student Fee Management System | [student_fee.cpp](Week6/student_fee.cpp) |
| 8 | Constructors and destructors | Bank Account System | [bank_account.cpp](Week8/bank_account.cpp) |
| 8 | Constructors and destructors | Hotel Room Booking System | [room_booking.cpp](Week8/room_booking.cpp) |

## How to compile and run

Using g++ (replace the path and file name as needed):

```
g++ Week1/sales_receipt.cpp -o sales_receipt
./sales_receipt
```

Or open any `.cpp` file in an IDE such as Code::Blocks or Dev-C++, then build and run.

Names are read with `cin`, so enter them as a single word (for example `John`).

## Coming later

Weeks 4, 5, 7 and 9 onward will be added in their own folders as they are covered.
